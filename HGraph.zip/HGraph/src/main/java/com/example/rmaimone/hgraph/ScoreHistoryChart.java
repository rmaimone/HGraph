package com.example.rmaimone.hgraph;

/**
 * Created by rmaimone on 22/11/2016.
 */
public class ScoreHistoryChart {
}
